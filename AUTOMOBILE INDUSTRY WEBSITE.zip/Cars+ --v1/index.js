$(document).ready(function(){
  $(".nav-link").click(function(){
    var n =  $(this).attr("id");
    var idAddress = `Home/${n}/${n}.html`
    console.log(idAddress);
    $("#home").load(idAddress);
  });
});

$(document).ready(function(){
  $(".dropdown-item").click(function(){
    var brandName =  $(this).attr("id");
    var brandAddress = "Brands/" + brandName + "/" + brandName + ".html"
    console.log(brandAddress);
    $("#home").load(brandAddress);
  });
});

$(document).ready(function(){
  $(".gallery").click(function(){
    var brandName =  $(this).attr("id");
    var brandAddress = "Brands/" + brandName + "/" + brandName + ".html"
    console.log(brandAddress);
    $("#home").load(brandAddress);
  });
});
